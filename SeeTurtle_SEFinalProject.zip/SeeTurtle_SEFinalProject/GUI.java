import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

//public class GUI
public class GUI extends Application {
	// attributes
	private BorderPane borderPane; // to lay out position of the children
	private Menu startMenu; // to show list of trash (plastic, metal, paper)
	private Menu plasticTrash;
	private Menu metalTrash;
	private Menu paperTrash;
	private ObservableList<Menu> itemList;
	private Pane regularPane;

	// Declare text to add to the regular pane
	private Label paneLabel1;
	private Label paneLabel2;
	private Label paneLabel3;
	private Label paneLabel4;
	private Label paneLabel5;

	public GUI() {
		borderPane = new BorderPane();
		startMenu = new Menu("START"); // to show list of trash (plastic, metal, paper)
		plasticTrash = new Menu("Plastic Trash");
		metalTrash = new Menu("Metal Trash");
		paperTrash = new Menu("Paper Trash");
		setTop();
		regularPane = new Pane();

		// LABEL #1: Instantiate label for regular pane (SEE TURTLE PROJECT)
		paneLabel1 = new Label("See Turtle Project");
		// Set the position
		paneLabel1.setLayoutX(215);
		paneLabel1.setLayoutY(150);
		paneLabel1.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, null, null)));
		// Set the appearance and color
		paneLabel1.setFont(Font.font("Times New Roman", FontWeight.BOLD, 70));
		paneLabel1.setTextFill(Color.WHITE);
		// Add label to the regular pane
		regularPane.getChildren().add(paneLabel1);

		// LABEL #2: Instantiate label for regular pane (DRONE SIMULATION)
		paneLabel2 = new Label("(Drone Simulation)");
		// Set the position
		paneLabel2.setLayoutX(338);
		paneLabel2.setLayoutY(210);
		paneLabel2.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, null, null)));
		// Set the appearance and color
		paneLabel2.setFont(Font.font("Times New Roman", FontWeight.BOLD, 40));
		paneLabel2.setTextFill(Color.WHITE);
		// Add label to the regular pane
		regularPane.getChildren().add(paneLabel2);

		// LABEL #3: Instantiate label for regular pane(DESCRIPTION)
		paneLabel3 = new Label("The purpose of this project is to develope a drone simulation that can"
				+ " pick up three different types of trash from");
		// Set the position
		paneLabel3.setLayoutX(20);
		paneLabel3.setLayoutY(480);
		paneLabel3.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, null, null)));
		// Set the appearance and color
		paneLabel3.setFont(Font.font("Times New Roman", FontWeight.BOLD, 20));
		paneLabel3.setTextFill(Color.WHITE);
		// Add label to the regular pane
		regularPane.getChildren().add(paneLabel3);

		// LABEL #4: Instantiate label for regular pane(DESCRIPTION)
		paneLabel4 = new Label("the surface of the beach and place each one of them into specific"
				+ " trash cans (plastic, metal, and paper). This sim-");
		// Set the position
		paneLabel4.setLayoutX(20);
		paneLabel4.setLayoutY(500);
		paneLabel4.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, null, null)));
		// Set the appearance and color
		paneLabel4.setFont(Font.font("Times New Roman", FontWeight.BOLD, 20));
		paneLabel4.setTextFill(Color.WHITE);
		// Add label to the regular pane
		regularPane.getChildren().add(paneLabel4);

		// LABEL #5: Instantiate label for regular pane(DESCRIPTION)
		paneLabel5 = new Label("ulation will be done to represent how the life of sea " + "creatures could be saved.");
		// Set the position
		paneLabel5.setLayoutX(20);
		paneLabel5.setLayoutY(520);
		paneLabel5.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, null, null)));
		// Set the appearance and color
		paneLabel5.setFont(Font.font("Times New Roman", FontWeight.BOLD, 20));
		paneLabel5.setTextFill(Color.WHITE);
		// Add label to the regular pane
		regularPane.getChildren().add(paneLabel5);
	}

	// To create a stage
	@Override
	public void start(Stage stage) {
		borderPane.setCenter(regularPane);
		Scene scene1 = new Scene(borderPane, 1000, 600);
		stage.setScene(scene1);
		stage.show();

		// Create a pane to hold the image views
		Image image = new Image("file:SeaTurtle_Image.jpg");
		ImageView imageView = new ImageView(image);
		regularPane.getChildren().add(imageView);
		imageView.toBack();
	}

	// Location of the menu
	private void setTop() {
		HBox top = new HBox();// layout component which positions all its child nodes(components) in a
								// horizontal row.
		top.setAlignment(Pos.CENTER);// method to center HBox pane within its layout area.Centers nodes within HBox
										// pane.
		setStartMenu();
		top.getChildren().add(new MenuBar(startMenu));
		borderPane.setTop(top);
	}

	// Set the list of Trash Types
	private void setStartMenu() {
		setTrashList();
		startMenu.getItems().addAll(itemList);
	}

	// Create list of Trash Types
	// Can always add a new type of trash and the code will still work
	private void setTrashList() {
		setTrash(plasticTrash);
		setTrash(metalTrash);
		setTrash(paperTrash);
		itemList = FXCollections.observableArrayList(plasticTrash, metalTrash, paperTrash);
	}

	// creates models menu inside of the hurricanes menu
	private void setTrash(Menu trash) {
		ObservableList<MenuItem> itemList;
		itemList = FXCollections.observableArrayList(plasticTrash, metalTrash, paperTrash);
		trash.getItems().addAll(itemList);
		setActions(itemList);
	}

	// this will set action
	private void setActions(ObservableList<MenuItem> itemList) {
		for (MenuItem items : itemList) {
			items.setOnAction(e -> {
				MenuItem item = (MenuItem) e.getSource();
				String text = item.getParentMenu().getParentMenu().getText() + item.getParentMenu().getText()
						+ item.getText();
				System.out.println(text);
			});
		}
	}

	private void tTrashPickUp(String trashType) {
		String fileName = "";
		if (trashType.contains("Plastic"))
			fileName = "BeachPlasticTrash.jpg";
		else if (trashType.contains("Metal"))
			fileName = "BeachMetalTrash.jpg";
		else
			fileName = "BeachPaperTrash.jpg";
	}

	public static void main(String[] args) {
		launch(args);
	}
}